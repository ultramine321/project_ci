<?php 

    class Home extends CI_Controller
    {
        public function index()
        {
            $data['page'] = $this->load->view('front/pages/home', null, true);
            $data['title'] = "Home";
            $this->load->view('front/partial/template', $data);
        }
    }


?>