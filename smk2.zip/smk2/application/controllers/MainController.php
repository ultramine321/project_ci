<?php 

    class MainController extends Ci_Controller 
    {
        public function index ()
        {
            redirect('front/Home');
        }
    }

?>